<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<title>Book Store</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="style.css" rel="stylesheet" type="text/css" />









<?php

EXTRACT( $_POST );

$query2 = " INSERT INTO login VALUES('$email','$password')";

if ( !( $database = mysql_connect( "localhost", "root", "1234" ) ) )                           
           die( "Could not connect to database" );


if ( !mysql_select_db( "bookshop", $database ) )
               die( "Could not open Products database" );
      

$result2 = mysql_query( $query2, $database);


mysql_close( $database );

?>









</head>
<body>
</body>
</html>