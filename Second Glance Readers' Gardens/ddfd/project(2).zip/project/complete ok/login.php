<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<?php

EXTRACT( $_POST );

$query = "SELECT  *  FROM login WHERE email = '$email' and pword='$password' ";


if ( !( $database = mysql_connect( "localhost", "root", "1234" ) ) )                           
           die( "Could not connect to database" );


if ( !mysql_select_db( "bookshop", $database ) )
               die( "Could not open bookshop database" );

$result = mysql_query( $query, $database );

$num=mysql_num_rows($result);

if($num==0)
	echo "<script type='text/javascript'>alert('Invalid email or password')</script>";
else
	echo "<script type='text/javascript'>alert('Login is successfull')</script>";


mysql_close( $database );

?>







</body>


